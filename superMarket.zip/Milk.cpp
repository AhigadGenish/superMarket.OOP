#include "Milk.h"
void Milk:: setMilkType(int type) {
	if (type < 1 || type > 4) {
		int validType;
		do {
			cout << "please insert valid type (1-4)" << endl;
			cin >> validType;
		} while (!(validType >= 1 && validType <= 4));
		this->_milkType = validType;
	}
	else
		this->_milkType = type;
}
void Milk:: setMilkName(string name) {
	this->_milkName = name;
}
void Milk:: setNumOfColors(int num) {
	this->_numOfColors = num;
}
void Milk:: setFatnessPrecent(int precent) {
	this->_fatnessPrecent = precent;
}
void Milk :: print() const {
	Product::print();
	cout << this->getMilkName() << "(" << this->getMilkType() << "," <<
		this->getNumOfColors() << "," << this->getFatnessPrecent() << ")";
}
float Milk:: price(int ad) const {
	return this->getMilkType() * (Product::price(ad) + this->getNumOfColors() - this->getFatnessPrecent());
}

Milk::Milk(int serialNum, char row, int shelf, int type, int quantity, int area, int milkType, int num, string name, int precent) :Product(serialNum, row, shelf, type, quantity, area) {
	this->setMilkName(name);
	this->setFatnessPrecent(precent);
	this->setNumOfColors(num);
	this->setMilkType(milkType);
}