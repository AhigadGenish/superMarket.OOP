#include "AnyMilk.h"
float AnyMilk:: price(int ad) const {
	return Milk::price(ad) + 5 * this->getNumOfParveIngerdients();
}
void AnyMilk:: setIndex(int j, string name) {
	if (j >= 0 && j < this->getNumOfParveIngerdients())
		this->_name[j] = name;
	else
		cout << "Index out of range" << endl;
}
void AnyMilk ::setNumOfIngredienrs(int num) {
	this->_parveIngredients = num;
}
void AnyMilk:: print() const {
	Milk::print();
	for (int i = 0;i < this->getNumOfParveIngerdients();i++)
		cout << this->getNames()[i] << " ";
	cout << "(" << this->getNumOfParveIngerdients() << ")" << endl;
}
AnyMilk:: AnyMilk(int serialNum, char row , int shelf , int type , int quatity , int area , int milkType , int num , string name , int precent , int parve ):Milk(serialNum,  row,  shelf,  type, quatity, area, milkType,  num, name,  precent){
	this->_name = NULL;
	this->setNumOfIngredienrs(parve);
	if (parve) {
		this->_name = new string[this->getNumOfParveIngerdients()];
		for (int i = 0;i < this->getNumOfParveIngerdients();i++) {
			string temp;
			cout << " please insert the name of the " << i + 1 << "parve product" << endl;
			cin >> temp;
			this->setIndex(i, temp);
		}
	}
}
AnyMilk:: ~AnyMilk() {

	if (!this->getNames())
		delete[] this->_name;

}