#include "Milk.h"
#pragma once
class Cheese : public Milk
{
	int _addition;
public:
	int getAddition()const {
		return this->_addition;
	}
	float price(int ad);
	void setAddition(int additions);
	void print() const;
	Cheese(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0, int area = 0, int milkType = 0, int num = 0, string name = "X", int precent = 0, int additions = 0);


};

