#include "Product.h"

void  Product:: setSerialNum(int serialNum) {
	this->_serialNum = serialNum;
}
void   Product::setQuantity(int quantity) {
	this->_quantity = quantity;
}
void  Product:: setType(int type) {
	if (type >= 0 && type <= 3 )
		this->_type = type;
	else {
		int validType;
		do {
			cout << "please insert valid type (1-3)" << endl;
			cin >> validType;
		} while (!(validType >= 1 && validType <= 3));
		this->_type = validType;
	}
}
void  Product::setArea(int area) {
	if(area >=0 && area <=3)
		this->_area = area;
	else {
		int validArea;
		do {
			cout << "please insert valid area (1-3)" << endl;
			cin >> validArea;
		} while (!(validArea >= 1 && validArea <= 3)); 
		this->_area = validArea;
	}
}
void Product::  setLocation(char row, int shelf) {
	if(row >='A' && row <='Z' || row == '#')
		this->_row = row;
	else {
		char validRow;
		do {
			cout << "please insert valid row (A-Z)" << endl;
			cin >> validRow;
		}
		while (!(validRow >= 'A' && validRow <= 'Z'));
		this->_row = validRow;
	}
	if (shelf >= 0 && shelf <= 5)
		this->_shelf = shelf;
	else {
		int validShelf;
		do {
			cout << "please insert valid shelf (1-5)" << endl;
			cin >> validShelf;
		} while (!(validShelf >= 1 && validShelf <= 5));
		this->_shelf = validShelf;
	}
	
}
void Product:: print() const {

	cout << this->getSerialNum() << " " << this->getRow() << " " << this->getShelf() << "(" << this->getQuantity()
		<< "," << this->getType() << "," << this->getArea() << ")";
}
Product:: Product(const Product& other) {
	this->setArea(other.getArea());
	this->setLocation(other.getRow(), other.getShelf());
	this->setQuantity(other.getQuantity());
	this->setSerialNum(other.getSerialNum());
	this->setType(other.getType());
}
Product:: Product(int serialNum, char row, int shelf, int type, int quatity, int area) {

	this->setSerialNum(serialNum);
	this->setLocation(row, shelf);
	this->setQuantity(quatity);
	this->setType(type);
	this->setArea(area);
}