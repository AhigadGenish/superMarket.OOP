#include "Market.h"

//Ahigad Genish
//Ahigad.genish@gmail.com
int main() {


	Market Shop("Shop", 5);
	for(int i = 0;i<6;i++)
		Shop.addProduct();

	Shop.printMarket();
	cout <<"The total price of all products:"<< Shop.totalPrice() << endl;
	
	return 0;
}