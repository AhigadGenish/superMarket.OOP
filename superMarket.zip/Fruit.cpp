#include "Fruit.h"
float Fruit :: price(int advertisingFactor) const {
	return (Farm::price(advertisingFactor) + (this->getSugarQuantity() / 2));
}
void Fruit:: print()const {
	Farm::print();
	cout << "(" << this->getSugarQuantity() << ")" << endl;
}
void Fruit :: setSugarQuantity(int sugarQuantity) {
	this->_sugarQuantity = sugarQuantity;
}
Fruit::Fruit(int serialNum, char row, int shelf, int type, int quatity, int area, string name, int farmType, int numofSeasoms, int numOfSuppliers, int sugarQuantity):Farm(serialNum, row, shelf, type, quatity, area, name, farmType, numofSeasoms, numOfSuppliers) {
	this->setSugarQuantity(sugarQuantity);
}