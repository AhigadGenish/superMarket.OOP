#include "Farm.h"
float Farm::price(int advertisingFactor) const {
	return (Product::price(advertisingFactor) * 3 * (5 - this->getNumOfSeasons()) + this->getFarmType() + this->getNumOfSuppliers() * 5);
}
void Farm::setFarmType(int type) {
	if( type == 1 || type == 2)
		this->_farmType = type;
	else {
		int validType;
		do {

			cout << "please enter valid type(1- vegetable, 2- fruit) " << endl;
			cin  >> validType;
		} while (validType != 1 && validType != 2);
	}
}
void Farm::setNumOfSuppliers(int numOfSuppliers) {

	this->_numOfSuppliers = numOfSuppliers;
}
void Farm::setNumOfSeasons(int numOfSeasons) {
	if (numOfSeasons >= 1 && numOfSeasons <= 4)
		this->_numOfSeasons = numOfSeasons;
	else {
		int validNumOfSeasons;
		do {

			cout << "please enter valid numOfSeasoms(1-4) " << endl;
			cin >> validNumOfSeasons;
		} while (!(validNumOfSeasons >= 1 && validNumOfSeasons <= 4));
	}
}
void Farm::setFarmName(string name) {
	this->_name = name;
}

void Farm::print() const {
	Product::print();
	cout <<" "<< this->getFarmName() << "(" << this->getFarmType() << ", " << this->getNumOfSeasons() << ", " << this->getNumOfSuppliers() << ")";

}
Farm:: Farm(int serialNum ,char row , int shelf , int type , int quantity , int area , string name , int farmType, int numOfSeasons, int numOfSuppliers):Product(serialNum,row,shelf,type,quantity,area){
	this->setFarmName(name);
	this->setFarmType(type);
	this->setNumOfSeasons(numOfSeasons);
	this->setNumOfSuppliers(numOfSuppliers);
}
