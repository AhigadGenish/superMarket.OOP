#include "Cheese.h"
float Cheese:: price(int ad) {
	return Milk::price(ad) + this->getAddition();
}
void Cheese::setAddition(int additions) {
	this->_addition = additions;
}
void Cheese::print() const {
	Milk::print();
	cout << "(" << this->getAddition() << ")" << endl;
}
Cheese::Cheese(int serialNum, char row, int shelf, int type, int quantity, int area, int milkType, int num, string name, int precent, int additions) :Milk(serialNum, row, shelf, type, quantity, area, milkType, num, name, precent) {
	this->setAddition(additions);
}