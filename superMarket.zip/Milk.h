#include "Product.h"
#pragma once

class Milk : public Product
{
	string _milkName;
	int _milkType;
	int _numOfColors;
	int _fatnessPrecent;


public:
	
	int getMilkType()const {
		return this->_milkType;
	}
	string getMilkName() const {
		return this->_milkName;
	}
	int getNumOfColors() const {
		return this->_numOfColors;
	}
	int getFatnessPrecent() const {
		return this->_fatnessPrecent;
	}

	void setMilkType(int type);
	void setMilkName(string name);
	void setNumOfColors(int num);
	void setFatnessPrecent(int precent);
	void print()const;
	float price(int ad)const;

	Milk(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0, int area = 0, int milkType = 0, int num = 0, string name = "X", int precent = 0);
};

