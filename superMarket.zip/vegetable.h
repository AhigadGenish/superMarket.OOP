#include "Farm.h"
class Vegetable : public Farm
{
	int _numOfVitamins;
public:
	int getNumOfVitamins() const {
		return this->_numOfVitamins;
	}
	float price(int advertisingFactor) const;
	void print()const;
	void setNumOfViatmins(int numOfVitamins);
	Vegetable(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0, int area = 0, string name = 0, int farmType = 0, int numofSeasoms = 0, int numOfSuppliers = 0, int numOfVitamins = 0);

};
