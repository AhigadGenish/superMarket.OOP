#include "Product.h"

class Package : public Product
{
	int _numOfProduct;
	string* _productsName;
	int _numOfColors;
public:
	int getNumOfProducts()const {
		return this->_numOfProduct;
	}
	int getNumOfColors()const {
		return this->_numOfColors;
	}
	string* getProductsName() const {
		return this->_productsName;
	}

	float price(int advertisingFactor) const;
	void setNumOfProducts(int num);
	void setNumOfColors(int n);
	void setIndex(int j, string name);
	void print() const;
	Package(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0, int area = 0, int numOfProducts = 0, int numOfColors = 0);
	~Package();



};

