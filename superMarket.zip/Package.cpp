#include "Package.h"
float Package::price(int advertisingFactor) const {
	return (Product::price(advertisingFactor) * 2 * this->getNumOfProducts() + (this->getNumOfColors() / 3));
}
void Package::setNumOfProducts(int num) {
	this->_numOfProduct = num;
}
void Package::setNumOfColors(int n) {
	this->_numOfColors = n;
} 
void Package::setIndex(int j, string name) {
	if (j >= 0 && j < this->getNumOfProducts())
		this->_productsName[j] = name;
	else
		cout << "Index out of range" << endl;
}
void Package::print() const {
	Product::print();
	for (int i = 0;i < this->getNumOfProducts();i++) {
		cout << this->getProductsName()[i] << "  ";
	}
	cout << "(" << this->getNumOfProducts() << "," << this->getNumOfColors() <<")"<< endl;
}
Package::Package(int serialNum, char row, int shelf, int type, int quantity, int area, int numOfProducts, int numOfColors) :Product(serialNum, row, shelf, type, quantity, area) {
	this->_productsName = NULL;
	this->setNumOfProducts(numOfProducts);
	this->setNumOfColors(numOfColors);
	this->_productsName = new string[this->getNumOfProducts()];
	for (int i = 0;i < numOfProducts;i++) {
		cout << " please insert the name of the " << i + 1 << "in package" << endl;
		cin >> this->_productsName[i];
	}

}
Package :: ~Package() {
	if (this->getProductsName())
		delete[] this->_productsName;
}