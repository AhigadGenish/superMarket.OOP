#include "Farm.h"

class Fruit :public Farm
{
	int _sugarQuantity;
public:
	int getSugarQuantity() const {
		return this->_sugarQuantity;
	}
	float price(int advertisingFactor) const;
	void print()const;
	void setSugarQuantity(int sugarQuantity);
	Fruit(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0, int area = 0, string name = 0, int farmType = 0, int numofSeasoms = 0, int numOfSuppliers = 0, int sugarQuantity = 0);

};

