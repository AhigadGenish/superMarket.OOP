#include "Fruit.h"
#include "vegetable.h"
#include "package.h"
#include "AnyMilk.h"
#include "Cheese.h"


class Market
{
	string _shopName;
	int _adFactor;
	int _numOfProduct;
	Product** _products;
protected:
	void insertProduct(Product* anyPtr);
public:
	string getShopName()const {
		return this->_shopName;
	}
	int getAdFactor()const {
		return this->_adFactor;
	}
	int getNumOfProducts()const {
		return this->_numOfProduct;
	}
	Product* getProduct(int index) const{
		if (index >= 0 && index < this->getNumOfProducts())
			return this->_products[index];
	}

	void setShopName(string name);
	void addProduct();
	void setNumOfPruducts(int num);
	void setAdFactor(int ad);
	float totalPrice() const;
	void printMarket() const;
	Market(string shopName,int adFactor);
	~Market();






};



