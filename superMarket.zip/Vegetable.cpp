#include "Vegetable.h"
float Vegetable::price(int advertisingFactor) const {

	return (Farm::price(advertisingFactor) + 2 * this->getNumOfVitamins());

}
void Vegetable::setNumOfViatmins(int numOfVitamins) {
	this->_numOfVitamins = numOfVitamins;
}
void Vegetable:: print() const {
	Farm::print();
	cout << "(" << this->getNumOfVitamins() << ")" << endl;
}
Vegetable::Vegetable(int serialNum, char row, int shelf, int type, int quantity, int area,string name, int farmType, int numofSeasoms, int numOfSuppliers, int numOfVitamins):Farm(serialNum,  row, shelf,  type,  quantity,  area, name,  farmType,  numofSeasoms, numOfSuppliers){
	this->setNumOfViatmins(numOfVitamins);
}