#include <iostream>
#include <string.h>
#pragma once


using namespace std;
class Product{ 

	int _serialNum;
	char _row;
	int _shelf;
	int _type;
	int _quantity;
	int _area;

protected:
	
	 int getType() const {
		 return this->_type;
	 }
public:
	int getSerialNum() const{
		return this->_serialNum;
	}
	
	int getQuantity() const {
		return this->_quantity;
	}
	int getArea() const {
		return this->_area;
	}
	char getRow() const {
		return this->_row;
	}
	int getShelf() const{
		return this->_shelf;
	}
	virtual float price(int advertisingFactor) const {
		return this->getQuantity() * this->getArea() * advertisingFactor;
	}

	void setSerialNum(int serialNum);
	void setType(int type);
	void setQuantity(int quantity);
	void setArea(int area);
	void setLocation(char row,int shelf);
	virtual void print() const;
	Product(const Product& other);
	Product(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0,int area = 0);
	virtual ~Product() {};





};

