#include "Milk.h"
#pragma once
class AnyMilk : public Milk
{
	int _parveIngredients;
	string* _name;
public:
	int getNumOfParveIngerdients() const {
		return this->_parveIngredients;
	}
	string* getNames() const {
		return this->_name;
	}
	float price(int ad) const;
	void setIndex(int j, string name);
	void setNumOfIngredienrs(int num);
	void print() const;
	AnyMilk(int serialNum = 0, char row = '#', int shelf = 0, int type = 0, int quatity = 0, int area = 0, int milkType = 0, int num = 0, string name = "X", int precent = 0, int parve = 0);
	~AnyMilk();
};

