#include "Market.h"
void Market::insertProduct(Product* anyPtr) {
	Product** temp = new Product * [this->getNumOfProducts()];
	for (int i = 0;i < this->getNumOfProducts()-1;i++)
		temp[i] = this->_products[i];
	temp[this->getNumOfProducts() - 1] = anyPtr;
	delete[] this->_products;
	this->_products = temp;
	cout << "product added" << endl;
}

void Market::addProduct() {

	int serialNum,  shelf, type, quantity, area;
	char row;
	int milkType, numOfColors, precent, additions, parve;
	string milkName;
	string farmName;
	int farmType, numOfSeasons, numOfSuppliers, numOfVitamins, sugarQuantity;
	int numOfProducts=0, num;
	Product* anyPtr = NULL;
	cout << "add new product " << endl;
	cout << "insert serial number please: " << endl;
	cin >> serialNum;
	do {
		cout << "please insert valid shelf (1-5)" << endl;
		cin >> shelf;
	} while (!(shelf >= 1 && shelf <= 5));
	do {
		cout << "please insert row (A-Z)" << endl;
		cin >> row;
	} while (!(row >= 'A' && row <= 'Z'));
	do {
		cout << "please insert type (1-3)" << endl;
		cin >> type;
	} while (!(type >= 1 && type <= 3));
	cout << "insert quantity please: " << endl;
	cin >> quantity;
	do {
		cout << "please insert valid area (1-3)" << endl;
		cin >> area;
	} while (!(area >= 1 && area <= 3));


	switch (type) {
	case 1: {
		do {
			cout << "please insert farmtype (1-2)" << endl;
			cin >> farmType;
		} while (!(farmType >= 1 && farmType <= 2));
		cout << "insert farm Name please: " << endl;
		cin >> farmName;
		cout << "insert numOfSeasons please: " << endl;
		cin >> numOfSeasons;
		cout << "insert numOfSuppliers please: " << endl;
		cin >> numOfSuppliers;
		switch (farmType) {
		case 1: {
			cout << "insert numOfVitamins please: " << endl;
			cin >> numOfVitamins;
			anyPtr = new Vegetable(serialNum, row, shelf, type, quantity, area, farmName,farmType, numOfSeasons, numOfSuppliers, numOfVitamins);

		}
			  break;
		case 2: {
			cout << "insert sugarQuantuty please: " << endl;
			cin >> sugarQuantity;
			anyPtr = new Fruit(serialNum, row, shelf, type, quantity, area, farmName, farmType, numOfSeasons, numOfSuppliers, sugarQuantity);
		}
			  break;
		}
	}
		  break;
	case 2: {
		do {
			cout << "please insert milktype (1-4)" << endl;
			cin >> milkType;
		} while (!(milkType >= 1 && milkType <= 4));
		cout << "insert milk Name please: " << endl;
		cin >> milkName;
		cout << "insert numOfColors please: " << endl;
		cin >> numOfColors;
		cout << "insert fatnessPrecent please: " << endl;
		cin >> precent;
		switch (milkType) {
		case 1: {
			cout << "insert additions please: " << endl;
			cin >> additions;
			anyPtr = new Cheese(serialNum, row, shelf, type, quantity, area, milkType, numOfColors, milkName, precent, additions);

		}
			  break;
		case 2: {
			cout << "insert parve ingerdients please: " << endl;
			cin >> parve;
			anyPtr = new AnyMilk(serialNum, row, shelf, type, quantity, area, milkType, numOfColors, milkName, precent, parve);
		}
			  break;

		default : {

			anyPtr = new Milk(serialNum, row, shelf, type, quantity, area, milkType, numOfColors, milkName, precent);

			break;
		}

		}

		 break;
	}

	case 3: {
		cout << "insert numOfProducts please: " << endl;
		cin >> numOfProducts;
		cout << "insert numOfColors please: " << endl;
		cin >> num;
		anyPtr = new Package(serialNum, row, shelf, type, quantity, area, numOfProducts, num);


		}
			break;
		default:
			break;
	}

	this->setNumOfPruducts(this->getNumOfProducts() + 1);
	this->insertProduct(anyPtr);
}
void Market::setNumOfPruducts(int num) {
	this->_numOfProduct = num;
}
void Market::setAdFactor(int ad) {
	this->_adFactor = ad;
}
void Market::setShopName(string name) {
	this->_shopName = name;
}
float Market:: totalPrice() const {
	float sum = 0;
	for (int i = 0;i < this->getNumOfProducts();i++)
		sum += this->getProduct(i)->price(this->getAdFactor());
	return sum;
}
void Market:: printMarket() const {
	cout << " **** Your superMarket: ****" << endl;
	cout << "(" << this->getShopName() << "," << this->getNumOfProducts() << "," << this->getAdFactor() << ")" << endl;
	for (int i = 0;i < this->getNumOfProducts();i++) {
		this->getProduct(i)->print();
		cout << endl;
	}
}
Market:: Market (string shopName, int adFactor) {
	this->setShopName(shopName);
	this->setAdFactor(adFactor);
	this->setNumOfPruducts(0);
	this->_products = NULL;
}
Market:: ~Market() {
	if (this->_products) {
		for (int i = 0;i < this->getNumOfProducts();i++)
			delete this->_products[i];
		delete[] this->_products;
	}
}