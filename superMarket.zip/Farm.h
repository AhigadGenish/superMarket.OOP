#include "Product.h"
#pragma once
class Farm	: public Product
{
	int _farmType;
	int _numOfSuppliers;
	int _numOfSeasons;
	string _name;
public:
	int getFarmType()const {
		return this->_farmType;
	}
	int getNumOfSuppliers()const {
		return this->_numOfSuppliers;
	}
	int getNumOfSeasons()const {
		return this->_numOfSeasons;
	}
	string getFarmName()const {
		return this->_name;
	}
	float price(int advertisingFactor) const;
	void setFarmType(int type);
	void setNumOfSuppliers(int numOfSuppliers);
	void setNumOfSeasons(int numOfSeasons);
	void setFarmName(string name);
	void print() const;
	Farm(int serialNum = 0, char row = '#' , int shelf = 0, int type = 0,int quantity = 0, int area = 0,string name = "empty", int farmType = 0, int numofSeasoms = 0, int numOfSuppliers = 0);

};

